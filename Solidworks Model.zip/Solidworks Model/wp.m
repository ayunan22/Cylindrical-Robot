% Step 1: Use your existing rigidBodyTree object
robot = DOF3_Arm;
robot.DataFormat = 'row'; % Ensure the data format is set to 'row'

% Step 2: Visualize the robot
show(robot);

% Step 3: Define the end-effector
ee = "Body3";

% Step 4: Generate the robot workspace
rng default
[workspace, configs] = generateRobotWorkspace(robot, {}, ee, IgnoreSelfCollision="on");

% Step 5: Compute manipulability index
mIdx = manipulabilityIndex(robot, configs, ee);

% Step 6: Visualize the workspace analysis
hold on
showWorkspaceAnalysis(workspace, mIdx, Voxelize=true);
axis auto
title("Voxelized Manipulability-Encoded Workspace");
hold off