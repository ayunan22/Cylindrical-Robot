Ts = 0.001;
[DOF3_Arm,ArmInfo] = importrobot('Assem21');
